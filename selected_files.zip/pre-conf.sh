sudo visudo
username ALL=(ALL) NOPASSWD: /path/to/your/bash/script.sh